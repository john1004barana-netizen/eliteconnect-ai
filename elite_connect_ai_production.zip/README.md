# Elite Connect AI — production package

This package contains the expanded production starter:
- backend API
- PostgreSQL/Prisma schema
- JWT auth + Firebase phone-token bridge
- OpenAI server-side assistant
- AI compatibility engine
- mutual matching
- authenticated Socket.IO private chat
- verification workflow
- admin verification/role endpoints
- Flutterwave Tanzania payment adapter + webhook
- Docker deployment
- Android native shell
- automated compatibility test
- production go-live/security runbook

This is not falsely advertised as "already live": third-party credentials, cloud accounts, domain, Firebase/Flutterwave ownership and Android signing are intentionally not included.

See:
`docs/GO_LIVE_STEP_BY_STEP.md`

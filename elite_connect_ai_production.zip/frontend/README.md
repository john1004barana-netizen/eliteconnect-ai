# Frontend integration

Tumia `index.html` ya prototype uliyonayo kama UI ya kuanzia.

API base:
`http://localhost:4000`

Login:
POST `/api/auth/register`
POST `/api/auth/login`

Baada ya login, hifadhi `token` na tuma:
`Authorization: Bearer <token>`

Endpoints kuu:
- GET `/api/me`
- PUT `/api/profile`
- POST `/api/matches/recommend`
- POST `/api/likes/:receiverId`
- GET `/api/matches`
- GET `/api/matches/:matchId/messages`
- POST `/api/ai/ask`
- POST `/api/payments/mobile-money`

Real-time chat:
Socket.IO event `join_match`, kisha `send_message`.

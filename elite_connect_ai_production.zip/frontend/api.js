const API_BASE = window.ELITE_API_BASE || "http://localhost:4000";

function apiHeaders() {
  const token = localStorage.getItem("elite_token");
  return {"Content-Type":"application/json", ...(token ? {"Authorization":`Bearer ${token}`} : {})};
}
async function api(path, options={}) {
  const r = await fetch(API_BASE+path, {...options, headers:{...apiHeaders(),...(options.headers||{})}});
  const data = await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error || "API error");
  return data;
}
async function registerUser(payload){
  const data=await api("/api/auth/register",{method:"POST",body:JSON.stringify(payload)});
  localStorage.setItem("elite_token",data.token); return data;
}
async function loginUser(payload){
  const data=await api("/api/auth/login",{method:"POST",body:JSON.stringify(payload)});
  localStorage.setItem("elite_token",data.token); return data;
}

plugins {
    id("com.android.application")
    kotlin("android")
}
android { namespace="com.eliteconnect.ai"; compileSdk=35
    defaultConfig { applicationId="com.eliteconnect.ai"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}

import admin from "firebase-admin";

let app: admin.app.App | null = null;

export function firebaseReady() {
  return Boolean(process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY);
}

function getApp() {
  if (!firebaseReady()) throw new Error("Firebase Admin is not configured");
  if (!app) {
    app = admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID!,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL!,
        privateKey: process.env.FIREBASE_PRIVATE_KEY!.replace(/\\n/g, "\n")
      })
    });
  }
  return app;
}

export async function verifyFirebaseIdToken(idToken: string) {
  return admin.auth(getApp()).verifyIdToken(idToken);
}

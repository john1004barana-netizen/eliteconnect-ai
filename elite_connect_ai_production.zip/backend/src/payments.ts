import crypto from "crypto";

export async function initiateFlutterwaveTz(input:{
  amount:number; email:string; phone:string; name:string; network?:string; txRef:string;
}) {
  const key=process.env.FLW_SECRET_KEY;
  if(!key) throw new Error("FLW_SECRET_KEY haijawekwa");
  const r=await fetch("https://api.flutterwave.com/v3/charges?type=mobile_money_tanzania",{
    method:"POST",
    headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},
    body:JSON.stringify({
      tx_ref:input.txRef, amount:input.amount, currency:"TZS",
      email:input.email, phone_number:input.phone, fullname:input.name,
      network:input.network
    })
  });
  return r.json();
}

export function verifyFlutterwaveWebhook(signature:string|undefined) {
  const expected=process.env.FLW_WEBHOOK_SECRET_HASH;
  if(!expected || !signature) return false;
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
}

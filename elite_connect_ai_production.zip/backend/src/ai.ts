import OpenAI from "openai";
import { prisma } from "./db.js";

const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey: process.env.OPENAI_API_KEY}) : null;

export async function datingAssistant(userId: string, question: string) {
  if (!client) return "AI haijawezeshwa bado. Weka OPENAI_API_KEY kwenye .env.";
  const user = await prisma.user.findUnique({where:{id:userId}});
  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5-mini",
    instructions: "Wewe ni msaidizi wa mahusiano wa Elite Connect. Jibu kwa Kiswahili rahisi, kwa heshima, usiahidi ndoa, usishinikize mtu kutuma pesa, na usitoe ushauri hatari.",
    input: `Mtumiaji: ${user?.name || "User"}\nSwali: ${question}`
  });
  return response.output_text;
}

export async function compatibility(a:any,b:any) {
  let score=0, reasons:string[]=[];
  if (a.gender && b.gender && a.gender !== b.gender) score += 10;
  if (a.city && b.city && a.city.toLowerCase()===b.city.toLowerCase()) {score+=10; reasons.push("Mnaishi eneo moja");}
  if (a.goal===b.goal) {score+=25; reasons.push("Malengo ya mahusiano yanafanana");}
  if (a.age && b.age) {
    const d=Math.abs(a.age-b.age);
    score += d<=3 ? 20 : d<=6 ? 14 : d<=10 ? 8 : 3;
    if (d<=6) reasons.push("Tofauti ya umri inaendana");
  }
  const ai=new Set(a.interests||[]), bi=new Set(b.interests||[]);
  const common=[...ai].filter(x=>bi.has(x));
  score += Math.min(20, common.length*5);
  if(common.length) reasons.push(`Mna interests zinazofanana: ${common.slice(0,3).join(", ")}`);
  const pA=a.personality||{}, pB=b.personality||{};
  if(pA.marriageTimeline && pA.marriageTimeline===pB.marriageTimeline){score+=15;reasons.push("Mna timeline inayofanana ya ndoa");}
  return {score:Math.min(100,score), reasons};
}

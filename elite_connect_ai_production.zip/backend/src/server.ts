import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import jwt from "jsonwebtoken";
import http from "http";
import { Server } from "socket.io";
import { z } from "zod";
import { prisma } from "./db.js";
import { checkPassword, hashPassword, requireAuth, signToken } from "./auth.js";
import { compatibility, datingAssistant } from "./ai.js";
import { initiateFlutterwaveTz, verifyFlutterwaveWebhook } from "./payments.js";
import { firebaseReady, verifyFirebaseIdToken } from "./firebase.js";

const app=express();
const server=http.createServer(app);
const io=new Server(server,{cors:{origin:process.env.FRONTEND_URL||"*"}});
app.use(helmet());
app.use(cors({origin:process.env.FRONTEND_URL||"*"}));
app.use(express.json({limit:"1mb"}));
app.use(rateLimit({windowMs:60_000,max:120}));

app.get("/health",(_,res)=>res.json({ok:true,service:"elite-connect-ai"}));

app.post("/api/auth/register",async(req,res)=>{
  try{
    const data=z.object({email:z.string().email(),password:z.string().min(8),name:z.string().min(2),phone:z.string().optional()}).parse(req.body);
    const exists=await prisma.user.findUnique({where:{email:data.email}});
    if(exists)return res.status(409).json({error:"Email tayari imesajiliwa"});
    const user=await prisma.user.create({data:{...data,passwordHash:await hashPassword(data.password)}});
    res.json({token:signToken(user.id),user:{id:user.id,email:user.email,name:user.name}});
  }catch(e){res.status(400).json({error:"Invalid registration data"});}
});

app.post("/api/auth/login",async(req,res)=>{
  const data=z.object({email:z.string().email(),password:z.string()}).parse(req.body);
  const user=await prisma.user.findUnique({where:{email:data.email}});
  if(!user?.passwordHash || !(await checkPassword(data.password,user.passwordHash))) return res.status(401).json({error:"Email au password si sahihi"});
  res.json({token:signToken(user.id),user:{id:user.id,email:user.email,name:user.name}});
});


async function requireAdmin(req:any,res:any,next:any){
  const id=req.userId;
  const u=await prisma.user.findUnique({where:{id},select:{role:true}});
  if(!u || (u.role!=="ADMIN" && u.role!=="MODERATOR")) return res.status(403).json({error:"Admin access required"});
  req.role=u.role; next();
}

app.post("/api/auth/firebase", async (req,res)=>{
  if(!firebaseReady()) return res.status(503).json({error:"Firebase is not configured"});
  try {
    const {idToken,name,phone}=z.object({idToken:z.string(),name:z.string().min(2).optional(),phone:z.string().optional()}).parse(req.body);
    const decoded=await verifyFirebaseIdToken(idToken);
    const email=decoded.email || `${decoded.uid}@phone.eliteconnect.local`;
    let user=await prisma.user.findUnique({where:{email}});
    if(!user){
      user=await prisma.user.create({
        data:{email,name:name || decoded.name || "Elite Connect User",phone:phone || decoded.phone_number || null,phoneVerified:Boolean(decoded.phone_number)}
      });
    } else if (decoded.phone_number && !user.phoneVerified) {
      user=await prisma.user.update({where:{id:user.id},data:{phone:decoded.phone_number,phoneVerified:true}});
    }
    res.json({token:signToken(user.id),user:{id:user.id,email:user.email,name:user.name,phoneVerified:user.phoneVerified}});
  } catch { res.status(401).json({error:"Invalid Firebase token"}); }
});

app.post("/api/verification/submit",requireAuth,async(req,res)=>{
  const id=(req as any).userId;
  const data=z.object({note:z.string().max(1000).optional()}).parse(req.body);
  const u=await prisma.user.update({where:{id},data:{verificationStatus:"PENDING",verificationNote:data.note}});
  res.json({status:u.verificationStatus});
});

app.get("/api/admin/users",requireAuth,requireAdmin,async(req,res)=>{
  const users=await prisma.user.findMany({orderBy:{createdAt:"desc"},take:200,select:{id:true,email:true,name:true,phone:true,age:true,city:true,phoneVerified:true,verificationStatus:true,verificationNote:true,verifiedAt:true,role:true,createdAt:true}});
  res.json(users);
});

app.post("/api/admin/users/:id/verify",requireAuth,requireAdmin,async(req,res)=>{
  const status=z.object({status:z.enum(["VERIFIED","REJECTED"]),note:z.string().max(1000).optional()}).parse(req.body);
  const u=await prisma.user.update({where:{id:req.params.id},data:{
    verificationStatus:status.status,verificationNote:status.note,
    verifiedAt:status.status==="VERIFIED"?new Date():null
  }});
  res.json({id:u.id,status:u.verificationStatus});
});

app.post("/api/admin/users/:id/role",requireAuth,requireAdmin,async(req,res)=>{
  if((req as any).role!=="ADMIN") return res.status(403).json({error:"Only ADMIN can change roles"});
  const {role}=z.object({role:z.enum(["USER","ADMIN","MODERATOR"])}).parse(req.body);
  const u=await prisma.user.update({where:{id:req.params.id},data:{role}});
  res.json({id:u.id,role:u.role});
});

app.get("/api/me",requireAuth,async(req,res)=>{
  const u=await prisma.user.findUnique({where:{id:(req as any).userId},select:{id:true,email:true,name:true,phone:true,age:true,gender:true,city:true,goal:true,bio:true,interests:true,phoneVerified:true,verificationStatus:true}});
  res.json(u);
});

app.put("/api/profile",requireAuth,async(req,res)=>{
  const userId=(req as any).userId;
  const data=z.object({
    name:z.string().min(2).optional(), age:z.number().int().min(18).max(100).optional(),
    city:z.string().max(80).optional(), bio:z.string().max(1000).optional(),
    goal:z.enum(["SERIOUS","MARRIAGE","DATING"]).optional(),
    interests:z.array(z.string()).max(20).optional(),
    lookingForMinAge:z.number().int().min(18).max(100).optional(),
    lookingForMaxAge:z.number().int().min(18).max(100).optional(),
    personality:z.record(z.string(),z.any()).optional()
  }).parse(req.body);
  const u=await prisma.user.update({where:{id:userId},data});
  res.json(u);
});

app.post("/api/matches/recommend",requireAuth,async(req,res)=>{
  const me=await prisma.user.findUnique({where:{id:(req as any).userId}});
  if(!me)return res.status(404).json({error:"User not found"});
  const candidates=await prisma.user.findMany({where:{id:{not:me.id},verificationStatus:"VERIFIED"},take:100});
  const scored=await Promise.all(candidates.map(async c=>({...c,...await compatibility(me,c)})));
  scored.sort((a,b)=>b.score-a.score);
  res.json(scored.slice(0,20).map(x=>({id:x.id,name:x.name,age:x.age,city:x.city,bio:x.bio,interests:x.interests,score:x.score,reasons:x.reasons,photoUrl:x.photoUrl})));
});

app.post("/api/likes/:receiverId",requireAuth,async(req,res)=>{
  const senderId=(req as any).userId, receiverId=req.params.receiverId;
  if(senderId===receiverId)return res.status(400).json({error:"Cannot like yourself"});
  await prisma.like.upsert({where:{senderId_receiverId:{senderId,receiverId}},create:{senderId,receiverId},update:{}});
  const reciprocal=await prisma.like.findUnique({where:{senderId_receiverId:{senderId:receiverId,receiverId:senderId}}});
  if(reciprocal){
    const [a,b]=[senderId,receiverId].sort();
    const ua=await prisma.user.findUnique({where:{id:a}}), ub=await prisma.user.findUnique({where:{id:b}});
    const c=await compatibility(ua,ub);
    const m=await prisma.match.upsert({where:{userAId_userBId:{userAId:a,userBId:b}},create:{userAId:a,userBId:b,score:c.score,reasons:c.reasons,status:"ACCEPTED"},update:{score:c.score,reasons:c.reasons,status:"ACCEPTED"}});
    return res.json({matched:true,match:m});
  }
  res.json({matched:false});
});

app.get("/api/matches",requireAuth,async(req,res)=>{
  const id=(req as any).userId;
  const ms=await prisma.match.findMany({where:{OR:[{userAId:id},{userBId:id}],status:"ACCEPTED"},include:{userA:true,userB:true},orderBy:{updatedAt:"desc"}});
  res.json(ms.map(m=>({...m,partner:m.userAId===id?m.userB:m.userA})));
});

app.get("/api/matches/:matchId/messages",requireAuth,async(req,res)=>{
  const id=(req as any).userId;
  const m=await prisma.match.findFirst({where:{id:req.params.matchId,OR:[{userAId:id},{userBId:id}],status:"ACCEPTED"}});
  if(!m)return res.status(404).json({error:"Match not found"});
  res.json(await prisma.message.findMany({where:{matchId:m.id},orderBy:{createdAt:"asc"}}));
});

app.post("/api/ai/ask",requireAuth,async(req,res)=>{
  const q=z.object({question:z.string().min(2).max(2000)}).parse(req.body);
  res.json({answer:await datingAssistant((req as any).userId,q.question)});
});

app.post("/api/payments/mobile-money",requireAuth,async(req,res)=>{
  const id=(req as any).userId;
  const data=z.object({amount:z.number().int().positive(),phone:z.string(),network:z.string().optional(),plan:z.string().default("PREMIUM")}).parse(req.body);
  const user=await prisma.user.findUnique({where:{id}});
  if(!user)return res.status(404).json({error:"User not found"});
  const txRef=`EC-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
  const payment=await prisma.payment.create({data:{userId:id,provider:"flutterwave",txRef,amount:data.amount}});
  try{
    const result=await initiateFlutterwaveTz({amount:data.amount,email:user.email,phone:data.phone,name:user.name,network:data.network,txRef});
    await prisma.payment.update({where:{id:payment.id},data:{providerId:String(result?.data?.id||""),rawResponse:result}});
    res.json({txRef,result});
  }catch(e){
    await prisma.payment.update({where:{id:payment.id},data:{status:"FAILED"}});
    res.status(502).json({error:"Payment provider error"});
  }
});

app.post("/api/payments/flutterwave/webhook",async(req,res)=>{
  const sig=req.headers["verif-hash"] as string|undefined;
  if(!verifyFlutterwaveWebhook(sig))return res.status(401).send("invalid");
  const d=req.body?.data;
  if(d?.tx_ref){
    const p=await prisma.payment.findUnique({where:{txRef:d.tx_ref}});
    if(p && d.status==="successful" && Number(d.amount)===p.amount){
      await prisma.payment.update({where:{id:p.id},data:{status:"SUCCESS",rawResponse:req.body,providerId:String(d.id)}});
      const ends=new Date(Date.now()+30*24*3600*1000);
      const sub=await prisma.subscription.create({data:{userId:p.userId,plan:"PREMIUM",amount:p.amount,endsAt:ends}});
      await prisma.payment.update({where:{id:p.id},data:{subscriptionId:sub.id}});
    }
  }
  res.json({received:true});
});

io.use((socket,next)=>{
  try {
    const token=String(socket.handshake.auth?.token||"");
    if(!token) return next(new Error("Unauthorized"));
    const payload=jwt.verify(token, process.env.JWT_SECRET || "dev-secret") as {userId:string};
    (socket as any).userId=payload.userId;
    next();
  } catch { next(new Error("Unauthorized")); }
});
io.on("connection",socket=>{
  socket.on("join_match",async({matchId}:{matchId:string})=>{
    const userId=(socket as any).userId;
    const m=await prisma.match.findFirst({where:{id:matchId,status:"ACCEPTED",OR:[{userAId:userId},{userBId:userId}]}});
    if(m) socket.join(`match:${matchId}`);
  });
  socket.on("send_message",async({matchId,body}:{matchId:string,body:string})=>{
    const senderId=(socket as any).userId;
    if(typeof body!=="string" || body.length===0 || body.length>4000)return;
    const m=await prisma.match.findFirst({where:{id:matchId,status:"ACCEPTED",OR:[{userAId:senderId},{userBId:senderId}]}});
    if(!m)return;
    const msg=await prisma.message.create({data:{matchId,senderId,body:body.trim()}});
    io.to(`match:${matchId}`).emit("message",msg);
  });
});

const port=Number(process.env.PORT||4000);
server.listen(port,()=>console.log(`Elite Connect API running on :${port}`));

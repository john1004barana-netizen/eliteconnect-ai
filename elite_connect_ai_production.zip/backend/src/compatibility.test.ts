import { compatibility } from "./ai.js";
const a={age:27,city:"Dar",goal:"MARRIAGE",interests:["business","travel"],personality:{marriageTimeline:"1-2y"}};
const b={age:29,city:"Dar",goal:"MARRIAGE",interests:["business","music"],personality:{marriageTimeline:"1-2y"}};
const r=await compatibility(a,b);
if(r.score < 70) throw new Error(`Expected strong match, got ${r.score}`);
console.log("compatibility test passed", r);

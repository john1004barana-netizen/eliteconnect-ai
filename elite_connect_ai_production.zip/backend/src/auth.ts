import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import type { Request, Response, NextFunction } from "express";

const secret = process.env.JWT_SECRET || "dev-secret";

export function signToken(userId: string) {
  return jwt.sign({ userId }, secret, { expiresIn: "7d" });
}
export function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}
export function checkPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const h = req.headers.authorization;
  if (!h?.startsWith("Bearer ")) return res.status(401).json({error:"Unauthorized"});
  try {
    const payload = jwt.verify(h.slice(7), secret) as {userId:string};
    (req as any).userId = payload.userId;
    next();
  } catch {
    return res.status(401).json({error:"Invalid token"});
  }
}

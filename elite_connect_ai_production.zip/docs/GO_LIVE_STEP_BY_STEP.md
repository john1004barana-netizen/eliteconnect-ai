# Elite Connect AI — hatua za mwisho za kwenda LIVE

## A. Accounts (WEWE ndiye unamiliki)
1. Create a production PostgreSQL database.
2. Create an OpenAI API project/key.
3. Create Firebase project and enable Phone Authentication.
4. Create Flutterwave account and enable Tanzania mobile-money collection.
5. Buy a domain and HTTPS hosting/VPS.

Do NOT send passwords/API keys in chat.

## B. Server
1. Copy `backend/.env.example` to `backend/.env`.
2. Set DATABASE_URL.
3. Set JWT_SECRET to a long random value.
4. Set OPENAI_API_KEY.
5. Set FLW_SECRET_KEY and FLW_WEBHOOK_SECRET_HASH.
6. Set Firebase Admin values.
7. Set FRONTEND_URL to your HTTPS frontend.

## C. Database
Run:
```bash
npm install
npm run db:generate
npm run db:migrate
```
Or deploy with Docker:
```bash
docker compose up -d --build
```

## D. Firebase phone OTP
1. Firebase Console -> Authentication -> Sign-in method -> Phone -> enable.
2. Set allowed SMS region policy.
3. Add your Android app package: `com.eliteconnect.ai`.
4. Download Firebase Android configuration and place it in the Android project as required by the Firebase Android setup.
5. Configure reCAPTCHA / Play Integrity as required by Firebase.
6. The app sends the OTP; after confirmation it gets an ID token.
7. POST that ID token to `/api/auth/firebase`.

## E. Flutterwave
1. Put the secret key only on the backend.
2. Use the `/api/payments/mobile-money` endpoint.
3. Configure webhook:
`https://YOUR-DOMAIN/api/payments/flutterwave/webhook`
4. Set the webhook secret hash.
5. Never activate Premium from the client response alone.
6. Activate Premium only after server-side webhook verification.

## F. OpenAI
1. Set OPENAI_API_KEY on the server only.
2. Keep the AI endpoint behind authenticated API routes.
3. Apply rate limits and usage monitoring.
4. Never put the key in Android/WebView JavaScript.

## G. Admin
After first registration, make the first owner account ADMIN using a secure database command/migration. Then:
- `/api/admin/users`
- `/api/admin/users/:id/verify`
- `/api/admin/users/:id/role`

Build an admin UI over these endpoints before opening public registration.

## H. Android
The `android/` directory is a native Android shell configured to load the HTTPS frontend. Replace:
`https://YOUR-DOMAIN.example`
with the real HTTPS frontend URL.

Install Android Studio + Android SDK, then:
```bash
./gradlew assembleDebug
```
For release:
```bash
./gradlew bundleRelease
```
Use YOUR OWN Play App Signing / upload key.

## I. Testing before customers
Test:
1. Register
2. Login
3. OTP success/failure
4. Profile update
5. Verification submission
6. Admin approve/reject
7. Match recommendation
8. Like A -> Like B -> Match
9. Two users join same chat
10. Unauthorized socket access is rejected
11. Block/report
12. Start payment
13. Webhook success
14. Wrong amount webhook rejected
15. Duplicate webhook is idempotent
16. Premium activates once
17. AI assistant
18. Rate limits
19. Account deletion
20. HTTPS only

## J. Security checklist
- Use HTTPS everywhere.
- Never commit `.env`.
- Rotate secrets if exposed.
- Use a managed DB with backups.
- Limit admin accounts.
- Log admin actions.
- Encrypt identity documents if you collect them.
- Delete identity documents when no longer needed.
- Require users to be 18+.
- Add privacy policy and terms.
- Add reporting/blocking.
- Add content moderation.
- Do not promise a guaranteed spouse/marriage.
- Verify payment server-side.

## What remains intentionally dependent on your accounts
No tool or developer can legitimately create the production keys, SMS sender/account ownership, payment merchant account, domain ownership or Play signing key for you. Those are the only external ownership steps.

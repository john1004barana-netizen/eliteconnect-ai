# Elite Connect AI — Setup

## 1. Requirements
- Node.js 20+
- PostgreSQL 15+
- Flutterwave merchant account for Tanzania mobile-money collections
- OpenAI API key
- Optional Firebase project if using Firebase phone verification in the mobile/web client.

## 2. Database
Create PostgreSQL database:
`elite_connect`

Copy:
`backend/.env.example` -> `backend/.env`

Set:
`DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/elite_connect`

Then:
```bash
npm install
npm run db:generate
npm run db:migrate
```

## 3. AI
Set:
`OPENAI_API_KEY=...`
and optionally:
`OPENAI_MODEL=...`

Never put the OpenAI key in the browser/mobile app. It belongs on the server.

## 4. Login
This backend includes email/password login using bcrypt + JWT.

For phone-number login/verification, Firebase Authentication can be added to the frontend. Firebase sends an SMS OTP and the backend can verify the Firebase ID token. See Firebase phone-auth documentation.

## 5. Profile verification
The database supports:
UNVERIFIED -> PENDING -> VERIFIED/REJECTED

For production, add an admin verification workflow. Do not automatically claim that an uploaded ID proves someone is trustworthy. Store sensitive identity documents only when legally necessary, encrypt storage, restrict access, and define retention/deletion rules.

## 6. Payments
The included adapter uses Flutterwave's Tanzania mobile-money charge endpoint with TZS and a unique tx_ref.

Configure:
- FLW_SECRET_KEY
- FLW_WEBHOOK_SECRET_HASH

Set the Flutterwave webhook URL to:
`https://YOUR_DOMAIN/api/payments/flutterwave/webhook`

The webhook handler checks the signature, transaction reference, final status and amount before activating Premium.

## 7. Chat security
The sample Socket.IO layer demonstrates the room/message flow. Before production:
- authenticate the Socket.IO handshake with the JWT;
- verify match membership server-side;
- rate-limit messages;
- sanitize/validate message size;
- implement block/report;
- add abuse moderation;
- use HTTPS/WSS.

## 8. Production checklist
- HTTPS
- managed PostgreSQL backups
- secret manager
- object storage for photos
- malware/content scanning for uploads
- admin roles and audit logs
- privacy policy + terms
- account deletion/export
- age gate 18+
- abuse reporting
- payment reconciliation
- monitoring and error tracking
- automated tests
